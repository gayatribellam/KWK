//
//  SpellerModel.swift
//  SpellerBee
//
//  Created by Apple on 8/16/18.
//  Copyright © 2018 KodeWithKlossy. All rights reserved.
//

import Foundation

class Speller{
    //let speller = SpellCD(entity: SpellCD.entity(), insertInto: context)
    var index = 0
    var words: [String] = ["map", "hat", "home", "bone", "poke", "knee", "toothbrush", "wrong", "again", "clean"]
    var word : String = ""
    var coins = 0
}
