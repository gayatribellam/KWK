//
//  StoreViewController.swift
//  SpellerBee
//
//  Created by Apple on 8/16/18.
//  Copyright © 2018 KodeWithKlossy. All rights reserved.
//

import UIKit
import CoreData

class StoreViewController: UIViewController {
    
    var gameView = GameViewController()
    var coin = Int()
   
    @IBOutlet weak var coins: UILabel!
    func getData() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"SpellCD")
        request.returnsObjectsAsFaults = false
        
        do {
            let result = try context.fetch(request)
            for data in result as![NSManagedObject] {
                coin = data.value(forKey : "coins") as! Int
                
            }
        } catch {
            print("failed")
        }
        
        
        
        
    }
    override func viewDidLoad() {
        getData()
        coins.text = "Drops of Honey: \(coin)"
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
//    if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext{
//        
//    }
//    
    @IBAction func bee45(_ sender: Any) {
//        if coin > 45{
//           coin = coin - 45
//        }
//        else{
          let alertController = UIAlertController(title: "You don't have enough coins.", message: "Try again later!", preferredStyle: UIAlertControllerStyle.alert)
           alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
         self.present(alertController, animated: true, completion: nil)
//        }
//        
   }
    @IBAction func bee55(_ sender: Any) {
//        if coin > 55{
//        coin = coins - 55
//        }
//        else{
           let alertController = UIAlertController(title: "You don't have enough coins.", message: "Try again later!", preferredStyle: UIAlertControllerStyle.alert)
           alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
            self.present(alertController, animated: true, completion: nil)
//        }
  }
   @IBAction func bee35(_ sender: Any) {
//        if coins > 35{
//        coins = coins - 35
//        }
//        else{
          let alertController = UIAlertController(title: "You don't have enough coins.", message: "Try again later!", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
//            
           self.present(alertController, animated: true, completion: nil)
//        }
   }
  @IBAction func bee70(_ sender: Any) {
//        if coins > 70{
//        coins = coins - 70
//        }
//        else{
          let alertController = UIAlertController(title: "You don't have enough coins.", message: "Try again later!", preferredStyle: UIAlertControllerStyle.alert)
           alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
    
           self.present(alertController, animated: true, completion: nil)
//        }
    }
@IBAction func bee100(_ sender: Any) {
//        if coins > 100{
//        coins = coins - 100
//        }
//        else{
          let alertController = UIAlertController(title: "You don't have enough coins.", message: "Try again later!", preferredStyle: UIAlertControllerStyle.alert)
           alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
    
            self.present(alertController, animated: true, completion: nil)
//        }
    }
//    
   
//
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

